# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 15:47:24 2022

@author: KMBL193407
"""
import os
import pandas as pd
from common import constants as con


def process_forex_trade_type_report(required_folder, dates_obtained):
    """
    Process Forex - Trade Type Reports

    Parameters
    ----------
    required_folder : TYPE : List
        Name of the folders.
    dates_obtained : TYPE : List
        Required Dates.

    Returns
    -------
    forex_trade : TYPE : DataFrame
        Forex Trade Data.

    """
    forex_trade = []
    for i, dates in enumerate(dates_obtained):
        current_path = os.path.join(con.TRADE_STORE, required_folder[i],
                                    f'forex_{dates.strftime("%Y%m%d")}.csv')
        df = pd.read_csv(current_path)

        # Replace Values
        df.loc[0:2, 'Tenor'] = df.loc[0:2, 'Trade Type']

        # Drop Trade Type
        df.drop(columns='Trade Type', inplace=True)

        # Drop NA
        df.dropna(inplace=True, how='all')

        # Add Date
        df['Dates'] = dates

        forex_trade.append(df)

    forex_trade = pd.concat(forex_trade, ignore_index=True)
    return forex_trade


def process_sdl_spread(required_folder):
    """
    Process SDL Spreads for Today

    Parameters
    ----------
    required_folder : TYPE : List
        Name of the folders.

    Returns
    -------
    df : TYPE
        DESCRIPTION.

    """
    current_path = os.path.join(con.TRADE_STORE, required_folder[0],
                                'CCIL1718.xls')
    df = pd.read_excel(current_path, header=3)

    # Drop Empty Columns and Rows with 5 or more empty values
    df.dropna(axis=0, inplace=True, thresh=5)
    df.dropna(how='all', axis=1, inplace=True)

    # Convert Maturity to Date
    df['Maturity date'] = pd.to_datetime(df['Maturity date']).dt.date

    return df


def slice_forex_intercategory_data(df, beg, end, col1=0, col2=8):
    """
    Slice Forex Inter Category Data

    Parameters
    ----------
    df : TYPE : DataFrame
        DataFrame to Slice.
    beg : TYPE : Integer
        Beginning Row.
    end : TYPE : Integer
        Ending Row.
    col1 : TYPE : Integer
        Beginning Column.
    col2 : TYPE : Integer
        Ending Column.

    Returns
    -------
    cash : TYPE : DataFrame
        DataFrame post processing.

    """
    # Slice Cash
    cash = df.iloc[beg:end, col1:col2].reset_index(drop=True)
    cash.columns = cash.iloc[0]
    cash = cash.iloc[1:, :].reset_index(drop=True)
    return cash


def process_segment_wise_forex_intercategory(required_folder):
    """
    Process Segment Wise Forex Inter Category - Participation Activity

    Parameters
    ----------
    required_folder : TYPE : List
        Name of the folders.

    Returns
    -------
    list : TYPE : List
        List of Activities across Tenors.

    """
    # Read Data
    current_path = os.path.join(con.TRADE_STORE, required_folder[0],
                                'CCIL1213.xls')
    df = pd.read_excel(current_path)

    # Slice Cash
    cash = slice_forex_intercategory_data(df, 4, 10)

    # Slice Tomorrow
    tom = slice_forex_intercategory_data(df, 15, 21)

    # Slice Spot
    spot = slice_forex_intercategory_data(df, 26, 32)

    # Slice Forward
    forward = slice_forex_intercategory_data(df, 37, 43)

    return [cash, tom, spot, forward]


def process_money_market_summary(unzip_list):
    """
    Process Money Market Summary

    Parameters
    ----------
    unzip_list : TYPE : List
        List of folders.

    Returns
    -------
    df_pivot : TYPE : DataFrame
        Pivoted DataFrame.

    """
    money_market_list = []

    for folder in unzip_list:
        # Read Data
        current_path = os.path.join(con.TRADE_STORE, folder, 'CCIL35.xls')
        df = pd.read_excel(current_path, header=1)

        df['Date'] = df['Date'].dt.date
        money_market_list.append(df[['Date', 'Market', 'Weighted Average  Rate',
                                     'Volume (Rs. Cr.)']])

    # Concat Lists
    money_market_df = pd.concat(money_market_list, ignore_index=True)

    # Loop over and convert strings to Floats
    for i, row in money_market_df.iterrows():
        try:
            money_market_df.loc[i, 'Weighted Average  Rate'] = \
                float(row['Weighted Average  Rate'])
            money_market_df.loc[i, 'Volume (Rs. Cr.)'] = \
                float(row['Volume (Rs. Cr.)'])
        except ValueError:
            money_market_df.loc[i, 'Weighted Average  Rate'] = 0
            money_market_df.loc[i, 'Volume (Rs. Cr.)'] = 0

    # Only Show for dates with values > 0
    money_market_df = money_market_df[money_market_df['Weighted Average  Rate'] > 0]

    # Sort and Drop Duplicates
    money_market_df.sort_values(by='Date', inplace=True)
    money_market_df.drop_duplicates(subset=['Date', 'Market'],
                                    inplace=True, keep='last')

    # Make a Pivot
    df_pivot = money_market_df.pivot(index='Date', columns='Market',
                                     values=['Weighted Average  Rate',
                                             'Volume (Rs. Cr.)'])
    # Reset INdex
    df_pivot = df_pivot.reset_index()

    # Set Column Names
    df_pivot = pd.DataFrame(df_pivot.values,
                            columns=['Dates', 'Call WAR', 'Repo WAR', 'TREP WAR',
                                     'Call Vol', 'Repo Vol', 'TREP Vol'])
    return df_pivot


def process_forex_spot(unzip_list):
    """
    Forex Spot Data

    Parameters
    ----------
    unzip_list : TYPE : List
        List of Folders Unzipped.

    Returns
    -------
    spot : TYPE : DataFrame
        Spot Rates.

    """
    spot_list = []
    for folder in unzip_list:
        # Read Data
        current_path = os.path.join(con.TRADE_STORE, folder, 'CCIL33.xls')
        df = pd.read_excel(current_path)
        spot_list.append(df.iloc[0:2, :])

    spot = pd.concat(spot_list, ignore_index=True)

    # Sort by Dates
    spot.sort_values(by='Date', inplace=True, ignore_index=True)

    # Drop Duplicates
    spot.drop_duplicates(subset='Date', inplace=True)

    spot['Date'] = pd.to_datetime(spot['Date']).dt.date

    return spot


def get_fpi_trades(unzip_list):
    """
    Get FPI Trades

    Parameters
    ----------
    unzip_list : TYPE : List
        List of Folders Unzipped.

    Returns
    -------
    fpi_trade : TYPE : DataFrame
        FPI Trade.

    """
    fpi_trade_list = []
    for folder in unzip_list:
        try:
            # Read Data
            current_path = os.path.join(con.TRADE_STORE, folder, 'CCIL47.xls')
            df = pd.read_excel(current_path, header=None)
            fpi_trade_list.append([df.iloc[0, 1], df.iloc[2, 0], df.iloc[2, 1]])
        except FileNotFoundError:
            continue

    fpi_trade = pd.DataFrame.from_records(fpi_trade_list,
                                          columns=['Dates', 'Trades', 'Volumes'])

    # Convert to Dates
    fpi_trade['Dates'] = pd.to_datetime(fpi_trade['Dates']).dt.date

    # Sort Values
    fpi_trade.sort_values(by='Dates', inplace=True, ignore_index=True)

    return fpi_trade


def get_market_activity(required_folder):
    """
    Get Market Activity across Categories

    Parameters
    ----------
    required_folder : TYPE : List
        Name of the folders.

    Returns
    -------
    list : TYPE : List
        List of Partcipant Activity by Characterisitics.

    """
    # Money Market Participant Activity
    current_path1 = os.path.join(con.TRADE_STORE, required_folder[0],
                                 'CCIL14.xls')
    money_market = pd.read_excel(current_path1, header=None)
    rev_repo = slice_forex_intercategory_data(money_market, 4, 11, col2=9)
    repo = slice_forex_intercategory_data(money_market, 14, 21, col2=9)

    # GSec Participant Activity
    current_path2 = os.path.join(con.TRADE_STORE, required_folder[0],
                                 'CCIL23.xls')
    gsec = pd.read_excel(current_path2, header=None)
    gsec_buy = slice_forex_intercategory_data(gsec, 3, 10, col2=9)
    gsec_sell = slice_forex_intercategory_data(gsec, 13, 20, col2=9)

    # Tbill Participant Activity
    current_path3 = os.path.join(con.TRADE_STORE, required_folder[0],
                                 'CCIL24.xls')
    tbill = pd.read_excel(current_path3, header=None)
    tbill_buy = slice_forex_intercategory_data(tbill, 3, 10, col2=9)
    tbill_sell = slice_forex_intercategory_data(tbill, 13, 20, col2=9)

    # Securities Segment
    current_path4 = os.path.join(con.TRADE_STORE, required_folder[0],
                                 'CCIL0809.xls')
    sec = pd.read_excel(current_path4, header=None, sheet_name='SEC')
    sec_buy = slice_forex_intercategory_data(sec, 3, 10, col2=9)
    sec_sell = slice_forex_intercategory_data(sec, 13, 20, col2=9)

    # Forex Segment
    frx = pd.read_excel(current_path4, header=None, sheet_name='FRX')
    frx_buy = slice_forex_intercategory_data(frx, 5, 11)
    frx_sell = slice_forex_intercategory_data(frx, 18, 24)

    return [rev_repo, repo, gsec_buy, gsec_sell, tbill_buy, tbill_sell,
            sec_buy, sec_sell, frx_buy, frx_sell]


def process_irs(required_folder, dates_obtained):
    """
    Process Interest Rate Swaps

    Parameters
    ----------
    required_folder : TYPE : List
        List of Required Folder.
    dates_obtained : TYPE : List
        Required Dates for Modification.

    Returns
    -------
    list
        List of MIBOR, MIFOR and MIFOR Modified DFs.

    """
    mibor_list, mifor_list, mifor_modified_list = [], [], []
    for i, dates in enumerate(dates_obtained):
        try:
            current_path = os.path.join(con.TRADE_STORE, required_folder[i],
                                        'CCIL32.xls')
            df = pd.read_excel(current_path, header=2)
        except FileNotFoundError:
            current_path = os.path.join(con.TRADE_STORE, required_folder[i],
                                        'CCIL32.xlsx')
            df = pd.read_excel(current_path, header=2)
        # MIBOR
        mibor = df.iloc[0:12, 0:8]
        mibor['Dates'] = dates
        mibor_list.append(mibor)
        # MIFOR
        mifor = df.iloc[17:24, 0:8]
        mifor['Dates'] = dates
        mifor_list.append(mifor)
        #MIFOR Modified
        mifor_modified = df.iloc[29:35, 0:8]
        mifor_modified['Dates'] = dates
        mifor_modified_list.append(mifor_modified)

    mibor = pd.concat(mibor_list, ignore_index=True)
    mifor = pd.concat(mifor_list, ignore_index=True)
    mifor_modified = pd.concat(mifor_modified_list, ignore_index=True)

    return [mibor, mifor, mifor_modified]


def process_trade_summary(required_folder):
    """
    Process Trade Summary

    Parameters
    ----------
    required_folder : TYPE : List
        List of Required Folder.

    Returns
    -------
    df : TYPE : DataFrame
        OTC and NDS Trades/Volumes.

    """
    current_path = os.path.join(con.TRADE_STORE, required_folder[0],
                                'CCIL25.xls')
    df = pd.read_excel(current_path, parse_dates=True, header=2)
    df = df.iloc[:, 0:5]
    df.columns = ['Dates', 'OTC: # Trades', 'OTC: Volumes', 'NDS: # Trades',
                  'NDS: Volumes']
    df['Dates'] = df['Dates'].dt.date
    return df


def process_term_money(required_folder):
    """
    Process Term Money

    Parameters
    ----------
    required_folder : TYPE : List
        List of Required Folder.

    Returns
    -------
    df : TYPE : DataFrame
        Term Money Data.

    """
    current_path = os.path.join(con.TRADE_STORE, required_folder[0],
                                'CCIL10.xls')
    df = pd.read_excel(current_path, sheet_name='Outstanding', parse_dates=True)
    df['SettlementDate'] = df['SettlementDate'].dt.date
    df['MaturityDate'] = df['MaturityDate'].dt.date
    return df


def process_category_market_share(required_folder):
    """
    Process Category Wise Market Share

    Parameters
    ----------
    required_folder : TYPE : List
        List of Folders.

    Returns
    -------
    Category-wise market share : list
        List of datframes for category wise market share.

    """
    current_path = os.path.join(con.TRADE_STORE, required_folder[0],
                                'CCIL15.xls')
    df = pd.read_excel(current_path)
    category_market_share = df.iloc[4:10, 0:9].reset_index(drop=True)
    category_market_share.columns = ['Category', 'Outright Buy', 'Outright Sell',
                                     'Gsec Buy', 'Gsec Sell', 'Tbill Buy',
                                     'Tbill Sell', 'SDL buy', 'SDL sell']

    share_constituent_deals = df.iloc[16:18, 0:4].reset_index(drop=True)
    share_constituent_deals.columns = df.iloc[15, 0:4]
    market_share_proprietary = df.iloc[24:30, 0:3].reset_index(drop=True)
    market_share_proprietary.columns = ['Category', 'Outright Buy', 'Outright Sell']
    return [category_market_share, share_constituent_deals, market_share_proprietary]


def process_settlement_data(required_folder):
    """
    Process Settlement Data

    Parameters
    ----------
    required_folder : TYPE : List
        List of Required Folders.

    Returns
    -------
    List of dataframes : list
        List of DataFrames post slicing.

    """
    current_path = os.path.join(con.TRADE_STORE, required_folder[0],
                                'CCIL02.xls')
    # Gsec
    gsec = pd.read_excel(current_path, sheet_name='SECURITIES VOLUMES')
    gsec_top5 = gsec.iloc[19:24, 0:10].reset_index(drop=True)
    gsec_top5.columns = con.GSEC_TOP5_COLUMNS

    gsec = gsec[~gsec.iloc[:, 0].isin(['Sub-total', 'Sub total', 'Sub-Total'])]
    gsec.reset_index(drop=True)

    gsec_today = pd.concat([gsec.iloc[8:12, 0], gsec.iloc[8:12, 3:5]],
                            axis=1)
    gsec_month = pd.concat([gsec_today, gsec.iloc[8:12, 5:7]], axis=1)
    gsec_fy = pd.concat([gsec_month, gsec.iloc[8:12, 7:9]], axis=1)
    gsec_fy.columns = con.GSEC_SETTLEMENT_COLUMNS

    # Forex
    forex = pd.read_excel(current_path, sheet_name='FOREX VOLUMES')
    forex_today = forex.iloc[7:11, 0:4]

    forex_month = pd.concat([forex_today, forex.iloc[7:11, 4:7]], axis=1)

    forex_fy = pd.concat([forex_month, forex.iloc[7:11, 7:10]], axis=1)
    forex_fy.columns = con.FOREX_SETTLEMENT_COLUMNS

    return [gsec_top5, gsec_fy, forex_fy]
