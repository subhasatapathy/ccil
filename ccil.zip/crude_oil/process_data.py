# -*- coding: utf-8 -*-
"""
Created on Tue Jan 18 16:09:53 2022

@author: KMBL193407
"""
import json
import pandas as pd
from urllib.request import urlopen

def get_petroleum_data(series_id):
    """
    Get Petroleum Data from EIA.Gov

    Parameters
    ----------
    series_id : TYPE : List
        ID of various Petroleum based series.

    Returns
    -------
    df : TYPE : DataFrame
        DataFrame of daily prices.

    """
    # API Components
    # store the URL in url as
    # parameter for urlopen
    key = "EIJ9zGjDoaa9Pv0ZW30LPphzjcfobqLFdLcUsSoU"
    api = f'http://api.eia.gov/series/?api_key={key}&series_id={series_id}'

    # store the response of URL
    response = urlopen(api)

    # storing the JSON response
    # from url in data
    data_json = json.loads(response.read())


    df = pd.DataFrame(data_json['series'][0]['data'], columns=['Date', 'Prices'])
    return df


def get_gold_data():
    import requests

    base_currency = 'USD'
    symbol = 'XAU'
    endpoint = 'timeseries'
    access_key = '2b996307xyeugx39m31gos4h6eu0el3kik1dh86x05mx9ilp8b8fg67exy8m'
    start_date = '2021-12-19'
    end_date = '2022-01-18'

    url = f"https://www.metals-api.com/api/{endpoint}?access_key={access_key}\
      &start_date={start_date}&end_date={end_date}&base={base_currency}&symbols={symbol}"
    resp = requests.get(url)
    resp.status_code
    print(resp.json())
