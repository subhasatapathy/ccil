# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 19:17:51 2021

@author: KMBL193407
"""
import re
import requests
import pandas as pd
from datetime import datetime


def get_today_data(data):
    """
    Append Today's data

    Parameters
    ----------
    data : TYPE : DataFrame
        Archive Data Till Yesterday.

    Returns
    -------
    df : TYPE : DataFrame
        Required Data with all Yield parameters.

    """
    # URL
    url = "https://www.ccilindia.com/RiskManagement/SecuritiesSegment/Pages/ZCYCCurrent.aspx"
    web_data = ''

    # Get Data from Website
    resp = requests.get(url, verify=False)
    if resp.ok:
        web_data = resp.text

    # Split the text to get required data to be scraped
    web_data2 = web_data.split('CCIL NSS ZCYC Parameters')[1]
    web_data2 = web_data2.split('N-S ZCYC Parameters')[0]

    # Get Specific Row to be scraped
    web_data3 = web_data2.split('<tr>')[2].strip()

    # Get Date
    date_scraped = datetime.strptime(re.findall(r'\d{1,2}-\w*-\d{4}', web_data3)[0],
                                     '%d-%b-%Y').date()
    values = re.findall(r'<td class="ms-vb2">(.*?)</td>', web_data3)

    # Data for the day
    df = pd.DataFrame({0: date_scraped, 1: [values[0]], 2: [values[1]],
                       3: [values[2]], 4: [values[3]], 5: [values[4]],
                       6: [values[5]]})
    df[[1, 2, 3, 4, 5, 6]] = df[[1, 2, 3, 4, 5, 6]].astype(float)
    df.columns = ['Date', 'BETA 0', 'BETA 1', 'BETA 2', 'BETA 3', 'TAU-1', 'TAU-2']

    data = pd.concat([data, df], ignore_index=True)
    data.drop_duplicates(subset='Date', inplace=True)
    return data
