# -*- coding: utf-8 -*-
"""
Created on Wed Jan 12 13:29:41 2022

@author: KMBL193407
"""
import time
import logging
import pandas as pd
from zcyc_etl import zcyc_main
from common import constants as con
from daily_trades.trade_data import process_url_download
from daily_trades.process_data import unzip_archives, filter_dates_folder
from daily_trades.process_files import process_forex_trade_type_report,\
    process_segment_wise_forex_intercategory, process_sdl_spread,\
        process_money_market_summary, process_forex_spot, get_fpi_trades,\
            get_market_activity, process_irs, process_trade_summary,\
                process_term_money, process_category_market_share,\
                    process_settlement_data

logging.basicConfig(level=logging.INFO, format='%(levelname)s:%(message)s')
log = logging.getLogger(__name__)

start_time = time.time()

# =============================================================================
# Process Bulk Downloads - Make Changes Manually
# =============================================================================
# Get ZCYC Data
_ = zcyc_main.process_zcyc_data([], process_archive=False, fetch_data=True)
log.info('ZCYC data downloaded')

start = input('Please add latest download number: Previous - 3782:')
try:
    start = int(start)
    url_list = process_url_download(start=start, stop=start-1, today_num=start)
    # Last - 3782 - 7 Feb
except ValueError:
    log.error(f"Can't convert string to int: {start}!. Skipping download.")
    
# =============================================================================
# Process Zip Files
# =============================================================================
# Unzip New Archives
unzip_list = unzip_archives()

# Get Required Dates and Folders
required_folder, dates_obtained = filter_dates_folder(unzip_list)

# Get ZCYC Data
zcyc_sovereign = zcyc_main.process_zcyc_data(dates_obtained,
                                             process_archive=False,
                                             fetch_data=False)
log.info('ZCYC data processed')

zcyc_key_rates = zcyc_main.process_key_zcyc_rates()
log.info('ZCYC Key rates Processed')

# Process Files from the chosen Folders
forex_trade = process_forex_trade_type_report(required_folder, dates_obtained)
log.info('Forex Trade data processed')

sdl_spread = process_sdl_spread(required_folder)
log.info('SDL Spreads data processed')

forex_participation = process_segment_wise_forex_intercategory(required_folder)
log.info('Forex Participation data processed')

money_market_summary = process_money_market_summary(unzip_list)
log.info('Money Market data processed')

spot = process_forex_spot(unzip_list)
log.info('Spot Rates processed')

fpi_trades = get_fpi_trades(unzip_list)
log.info('FPI Trades data processed')

participant_activity = get_market_activity(required_folder)
log.info('Participant Activity data processed')

irs_list = process_irs(required_folder, dates_obtained)
log.info('IRS Data Processed')

trade_summary = process_trade_summary(required_folder)
log.info('Trade Summary Data Processed')

term_money = process_term_money(required_folder)
log.info('Term Money Data Processed')

category_market_share = process_category_market_share(required_folder)
log.info('Category wise Market Share processed')

settlement_volumes = process_settlement_data(required_folder)
log.info('Settlement Data Processed')

# Convert Dates List to DataFrame
dates_obtained = pd.DataFrame({'Dates' : dates_obtained,
                               'Category' : con.DATE_CATEGORY})

with pd.ExcelWriter(con.PROCESSED_DATA) as writer:
    zcyc_sovereign.to_excel(writer, sheet_name='Sovereign Yield')
    zcyc_key_rates.to_excel(writer, sheet_name='Sovereign Key Yields',
                            index=False)
    forex_trade.to_excel(writer, sheet_name='Forex Trade', float_format="%.2f")
    sdl_spread.to_excel(writer, index=False, sheet_name='SDL Spread',
                        float_format="%.2f")
    money_market_summary.to_excel(writer, index=False, float_format="%.4f",
                                  sheet_name='Money Market Summary')
    spot.to_excel(writer, index=False, sheet_name='Spot Rates',
                  float_format="%.2f")
    fpi_trades.to_excel(writer, index=False, sheet_name='FPI Trades',
                        float_format="%.4f")
    trade_summary.to_excel(writer, index=False, sheet_name='Trade Summary',
                           float_format="%.2f")
    term_money.to_excel(writer, index=False, sheet_name='Term Money',
                        float_format="%.2f")
    for i, df in enumerate(forex_participation):
        df.to_excel(writer, index=False, sheet_name=con.FOREX_PARTICIPANTS[i],
                    float_format="%.2f")
    for i, df in enumerate(participant_activity):
        df.to_excel(writer, index=False, sheet_name=con.MARKET_PARTICIPANTS[i],
                    float_format="%.2f")
    for i, df in enumerate(irs_list):
        df.to_excel(writer, index=False, sheet_name=con.IRS[i],
                    float_format="%.2f")
    for i, df in enumerate(category_market_share):
        df.to_excel(writer, index=False, sheet_name=con.CATEGORY_MARKET_SHARE[i],
                    float_format="%.2f")
    for i, df in enumerate(settlement_volumes):
        df.to_excel(writer, index=False, sheet_name=con.SETTLEMENT_VOLUMES[i],
                    float_format="%.2f")
    dates_obtained.to_excel(writer, sheet_name='Dates_Category')

log.info('Data written to file!')
log.info(f'Process completed in {round(time.time() - start_time, 2)} seconds.')
