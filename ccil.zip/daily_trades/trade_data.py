# -*- coding: utf-8 -*-
"""
Created on Tue Jan  4 16:55:48 2022

@author: KMBL193407
"""
import os
import time
import random
import logging
import requests
from datetime import date, timedelta
from common import constants as con

log = logging.getLogger(__name__)

def download_file_from_url(url):
    """
    Download File from URL

    Parameters
    ----------
    url : TYPE : String
        URL to Download the file.

    Returns
    -------
    None.

    """
    resp = requests.get(url, verify=False)
    if resp.ok:
        with open(os.path.join(con.TRADE_STORE, os.path.basename(url)),
                  'wb') as fd:
            for chunk in resp.iter_content():
                fd.write(chunk)
        return True
    else:
        return resp.ok

#date_val = date(year=2020, month=4, day=30)
# last Downloaded - i == 3224
#https://www.ccilindia.com/Research/Statistics/Lists/DailyDataForInfoVendors/Attachments/2775/DFIV_30_04_2020.zip
def process_url_download(start, stop, today_num):
    """
    Process URL to Download File

    Parameters
    ----------
    start : TYPE : Integer
        Number to Start from.
    stop : TYPE : Integer
        Number to Stop Download at.
    today_num : TYPE : Integer
        Number to Skip
    date_val : TYPE : Date
        Date Default

    Returns
    -------
    None.

    """
    url_list = []
    sleep_secs = [1, 2, 3, 4, 5]

    for i in range(start, stop, -1):
        if i == today_num:
            date_val = date.today()
        else:
            date_val -= timedelta(days=1)
        url = f"{con.DOMAIN_DAILY_DATA}{i}/DFIV_{date_val.strftime('%d_%m_%Y')}.zip"
        download_status = download_file_from_url(url)
        if not download_status:
            n = 0
            while True:
                print(n)
                date_val -= timedelta(days=1)
                url = f"{con.DOMAIN_DAILY_DATA}{i}/DFIV_{date_val.strftime('%d_%m_%Y')}.zip"
                download_status = download_file_from_url(url)
                if download_status:
                    url_list.append(url)
                    break
                elif n == 5:
                    date_val += timedelta(days=7)
                    break
                else:
                    n += 1
        else:
            url_list.append(url)
            log.info(f'File no.: {i} downloaded')

        # Make the Process Sleep
        sleep_time = random.choice(sleep_secs)
        time.sleep(sleep_time)
        log.info(f'Slept for {sleep_time} seconds.')
    return url_list
