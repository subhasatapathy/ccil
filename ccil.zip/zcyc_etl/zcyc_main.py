# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 15:03:33 2021

@author: KMBL193407
"""
import math
import logging
import pandas as pd
from datetime import date
from zcyc_etl import process_data
from common import constants as con
from zcyc_etl.create_file_from_archive import get_data_from_archive

log = logging.getLogger(__name__)


def process_zcyc_data(dates_obtained, process_archive=False, fetch_data=True):
    """
    Process ZCYC Data and generate an Excel File

    Parameters
    ----------
    process_archive : TYPE, optional : Boolean
        If True, generatess data from archive. The default is False.

    fetch_data : TYPE, optional : Boolean
        If True, gets data from CCIL website. The default is True.

    dates_obtained : TYPE : List
        List of Dates Obtained

    Returns
    -------
    df : TYPE : DataFrame.
        DataFrame with ZCYC Parameters obtained

    """
    # If True then get Data From Archive
    if process_archive:
        get_data_from_archive()
        log.info('Combining Data from Archives')

    # Read Data
    data = pd.read_excel(con.ZCYC_DATA_INPUT)
    data['Date'] = data['Date'].dt.date

    # Check for New Values
    if date.today() not in data['Date'].tolist() and fetch_data:
        data = process_data.get_today_data(data)
        log.info(f'Added Data for {date.today()}')
        # Write the new Value to File
        data.to_excel(con.ZCYC_DATA_INPUT, index=False, freeze_panes=(1,1))

    if not fetch_data:
        # Filter required Dates
        data = data.merge(pd.Series(dates_obtained, name='Date'), how='inner',
                           on='Date')
        data.sort_values(by='Date', ascending=False, inplace=True)
    
        # Process Yield rates
        df = process_yield_rates(data)
    
        # Transpose
        df = df.T
    
        # Add Date
        df.columns = con.DATE_CATEGORY
    else:
        df = 0
    return df

def process_yield_rates(data):
    """
    Process Yield Rates

    Parameters
    ----------
    data : TYPE : DataFrame
        ZCYC Paramaters Time Series Data.

    Returns
    -------
    df : TYPE : DataFrame
        ZCYC Computed.

    """
    # Get Rates Across the Tenor
    yield_rates = []
    for i, row in data.iterrows():
        tenor_wise = []
        for m in con.TENOR:
            v1 = row['BETA 0']
            v2 = (row['BETA 1'] + row['BETA 2']) * \
                (1 - math.exp(-m /row['TAU-1'])) / (m/row['TAU-1'])
            v3 = row['BETA 2'] * math.exp(-m /row['TAU-1'])
            v4 = row['BETA 3'] * (1 - math.exp(-m /row['TAU-2'])) / (m/row['TAU-2'])
            v5 = row['BETA 3'] * math.exp(-m /row['TAU-2'])
            val = v1 + v2 - v3 + v4 - v5

            tenor_wise.append(val)
        yield_rates.append(tenor_wise)

    # Create a DataFrame for all Dates
    df = pd.DataFrame.from_records(yield_rates)
    log.info('Yield Values Computed')

    # Round Tenor to 1 decimal place and set column header
    tenor = [round(t, 1) for t in con.TENOR]
    df.columns = tenor
    return df


def process_key_zcyc_rates():
    """
    Process Key ZCYC Rates

    Returns
    -------
    df : TYPE : DataFrame
        Select ZCYC Time Series for Specific Tenors.

    """
    # Read Excel
    data = pd.read_excel(con.ZCYC_DATA_INPUT)

    # Convert Datetime to Date
    data['Date'] = pd.to_datetime(data['Date']).dt.date

    # Process Yield rates
    df = process_yield_rates(data)

    # Concat Dates
    df = pd.concat([data['Date'], df], axis=1)

    # Select Required Columns
    df = df[['Date', 0, 1, 10]]

    return df
