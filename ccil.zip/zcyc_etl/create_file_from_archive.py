# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 18:04:42 2021

@author: KMBL193407
"""
import os
import pandas as pd
from common import constants as con

def get_data_from_archive():
    """
    Get Data from Archive in Excel Format

    Returns
    -------
    None.

    """
    # List Files with XLS extension
    excel_files = os.listdir(con.ZCYC_DATA_STORAGE)
    excel_files = [os.path.join(con.ZCYC_DATA_STORAGE, x) for x in excel_files
                   if x.endswith('.xls')]

    # Slice DataFrames to get it in Required Format
    df_list = [pd.read_excel(x, sheet_name='ZCYC') for x in excel_files]
    df_list = [df.iloc[1:, 0:7] for df in df_list]

    # Concat the DataFrame
    data = pd.concat(df_list)

    # Rename Columns
    data.columns = ['Date', 'BETA 0', 'BETA 1',	'BETA 2', 'TAU-1', 'BETA 3', 'TAU-2']

    # Convert Specific Columns to Float
    data[['BETA 0', 'BETA 1',	'BETA 2', 'TAU-1', 'BETA 3', 'TAU-2']] = \
        data[['BETA 0', 'BETA 1',	'BETA 2', 'TAU-1', 'BETA 3', 'TAU-2']].astype(float)

    # Infer Date
    data['Date'] = pd.to_datetime(data['Date'], infer_datetime_format=True)
    data['Date'] = data['Date'].dt.date

    # Sort Data by Date
    data.sort_values(by='Date', inplace=True, ignore_index=True)

    # Drop Duplicates
    data.drop_duplicates(subset='Date', inplace=True)

    # Write Data to Excel
    data.to_excel(con.ZCYC_DATA_INPUT, index=False)
