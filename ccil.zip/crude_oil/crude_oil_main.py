# -*- coding: utf-8 -*-
"""
Created on Tue Jan 18 15:50:38 2022

@author: KMBL193407
"""
from crude_oil import process_data


# Brent, WTI, Keroscene - Jet Fuel, Natural Gas
series_id = ["PET.RBRTE.D", "PET.RWTC.D", "PET.EER_EPJK_PF4_RGC_DPG.D",
             "NG.RNGWHHD.D"]

petrol_data = []
for ids in series_id:
    petrol_data.append(process_data.get_petroleum_data(ids))
