# -*- coding: utf-8 -*-
"""
Created on Wed Jan 12 14:39:33 2022

@author: KMBL193407
"""
import os
import zipfile
import pandas as pd
from common import constants as con
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

def read_directory_zip_files():
    """
    Read Directory for Zip/Un-zipped Files

    Returns
    -------
    zip_list : TYPE : List.
        Files available in Unzipped Form.
    unzip_list : TYPE : List.
        Folders available in Unzipped Form.

    """
    # List of all files in the said directory
    dir_list = os.listdir(con.TRADE_STORE)

    # List of Zip files
    zip_list = [files for files in dir_list if files.endswith('.zip')]

    # Folder List
    unzip_list = [files for files in dir_list if not files.endswith('.zip')]
    return zip_list, unzip_list


def unzip_archives():
    """
    Unzip Archives

    Returns
    -------
    unzip_list : TYPE : List.
        Files available in Unzipped Form.

    """
    zip_list, unzip_list = read_directory_zip_files()

    # New Files to UnZip
    unzip_source = [files + '.zip' for files in unzip_list]
    zip_list = [f for f in zip_list if f not in unzip_source]

    # unzip Files
    for zip_file in zip_list:
        try:
            os.mkdir(os.path.join(con.TRADE_STORE, zip_file.replace('.zip', '')))
            with zipfile.ZipFile(os.path.join(con.TRADE_STORE, zip_file),"r") as zip_ref:
                zip_ref.extractall(os.path.join(con.TRADE_STORE, zip_file.replace('.zip', '')))
        except FileExistsError:
            continue
    _, unzip_list = read_directory_zip_files()
    return unzip_list


def filter_dates_folder(unzip_list):
    """
    Filter Dates Folder based on set dates

    Parameters
    ----------
    unzip_list : TYPE : List
        List of Folders Unzipped.

    Returns
    -------
    required_folder : TYPE : List
        Folders available post Unzipping.
    dates_obtained : TYPE : List
        Dates of those folders.

    """
    # Replace DFIV with Empty String
    unzip_list_dates = [x.replace('DFIV_', '') for x in unzip_list]

    # Extract Dates
    unzip_list_dates = [datetime.strptime(x, '%d_%m_%Y').date() for x in unzip_list_dates]

    # Sorted list
    df = pd.DataFrame({'Folder Name': unzip_list, 'Dates': unzip_list_dates})
    df.sort_values(by='Dates', ascending=False, inplace=True, ignore_index=True)

    # Dates
    latest_date = df.loc[0, 'Dates']
    yesterday = latest_date - timedelta(days=1)
    last_week = latest_date - timedelta(days=7)
    last_month = latest_date - relativedelta(months=1)
    beginning_of_month = latest_date.replace(day=1)
    last_year = latest_date - relativedelta(years=1)

    # Required_dates
    req_dates = [latest_date, yesterday, last_week, last_month,
                 beginning_of_month, last_year]

    # Filtered Dates and Folders
    required_folder, dates_obtained = [], []
    for dates in req_dates:
        df_filtered = df[df['Dates'] <= dates].reset_index(drop=True)
        required_folder.append(df_filtered.loc[0, 'Folder Name'])
        dates_obtained.append(df_filtered.loc[0, 'Dates'])

    return required_folder, dates_obtained
