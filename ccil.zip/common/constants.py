# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 19:51:45 2021

@author: KMBL193407
"""
import os

TENOR = [0.00273972602739726, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8,
         8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15,
         15.5, 16, 16.5, 17, 17.5, 18, 18.5, 19, 19.5, 20, 20.5, 21, 21.5,
         22, 22.5, 23, 23.5, 24, 24.5, 25, 25.5, 26, 26.5, 27, 27.5, 28, 28.5,
         29, 29.5, 30, 30.5, 31, 31.5, 32, 32.5, 33, 33.5, 34, 34.5, 35, 35.5,
         36, 36.5, 37, 37.5, 38, 38.5, 39, 39.5, 40]

SETTLEMENT_VOLUMES = ['gsec_top5', 'gsec_settlement', 'forex_settlement']
CATEGORY_MARKET_SHARE = ['category_market_share', 'share_constituent_deals',
                         'market_share_proprietary']
IRS = ['MIBOR', 'MIFOR', 'MIFOR_MODIFIED']
FOREX_PARTICIPANTS = ['cash', 'tom', 'spot', 'forward']
MARKET_PARTICIPANTS = ['rev_repo', 'repo', 'gsec_buy', 'gsec_sell', 'tbill_buy',
                       'tbill_sell', 'sec_buy', 'sec_sell', 'frx_buy', 'frx_sell']
DATE_CATEGORY = ['Today', 'Yesterday', '7 days back',
                 'Same day last month', 'First day of the month',
                 'Same day Last year']
GSEC_TOP5_COLUMNS = ['Security Description', 'Maturity Date', 'No of Trades',
                     'Amount (F.V)', 'PLTP (Rs.)', 'PYTM (%)', 'High (Rs.)',
                     'Low (Rs.)', 'LTP (Rs.)', 'YTM (%)']
FOREX_SETTLEMENT_COLUMNS = ['Trade Type', 'No. of trades', 'USD Mn', 'INR Mn',
                            'No. of trades - Month', 'USD Mn - Month',
                            'INR Mn - Month', 'No. of trades - FY', 'USD Mn - FY',
                            'INR Mn - FY']
GSEC_SETTLEMENT_COLUMNS = ['Trade Type', 'No. of trades - Today',
                           'Amount (F.V.) Today', 'No. of trades - Cumm Month',
                           'Amount (F.V.) Cumm Month', 'No. of trades - FY',
                           'Amount (F.V.) FY']

CCIL_DATA = r'T:/Data/Power BI/CCIL Trade Statistics/data'

# Yield Data
ZCYC_DATA_STORAGE = os.path.join(CCIL_DATA, 'zcyc_data')
ZCYC_DATA_INPUT = os.path.join(CCIL_DATA, 'output/Data.xlsx')

# Daily Trades
TRADE_STORE = os.path.join(CCIL_DATA, 'trade_data')
DOMAIN_DAILY_DATA = "https://www.ccilindia.com/Research/Statistics/Lists/DailyDataForInfoVendors/Attachments/"

# Output
PROCESSED_DATA = os.path.join(CCIL_DATA, 'output/Processed.xlsx')
